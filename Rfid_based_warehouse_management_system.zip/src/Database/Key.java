
package Database;

public class Key {
    private static final int key=5;
    
    public int getKey(){
        return key;
    }
}
